package com.Bank.BankingSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
