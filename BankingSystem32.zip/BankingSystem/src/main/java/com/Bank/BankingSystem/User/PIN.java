package com.Bank.BankingSystem.User;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Entity
public class PIN {
    
    @Id
    private int id;
    
    @Pattern(regexp = "\\d{4}", message = "PIN must be exactly 4 digits")
    private String Tpin; // Change type to String to use Pattern validation

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTpin() {
        return Tpin;
    }

    public void setTpin(String tpin) {
        Tpin = tpin;
    }

    @Override
    public String toString() {
        return "PIN [id=" + id + ", Tpin=" + Tpin + "]";
    }

    public PIN(int id, String tpin) {
        super();
        this.id = id;
        Tpin = tpin;
    }

    public PIN() {
        super();
        // TODO Auto-generated constructor stub
    }
}
