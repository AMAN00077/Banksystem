package com.Bank.BankingSystem.User.Service;

import java.util.List;

import com.Bank.BankingSystem.User.M_Passbook;

public interface PassbookService {
    M_Passbook savePassbookEntry(M_Passbook passbookEntry);
    
    double getLatestBalance(int userId);

	List<M_Passbook> getPassbookEntriesByUserId(int userId);
}
