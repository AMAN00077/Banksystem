package com.Bank.BankingSystem.User.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Bank.BankingSystem.User.Loan;
import com.Bank.BankingSystem.User.User;
import com.Bank.BankingSystem.User.Dao.LoanRepository;
import com.Bank.BankingSystem.User.Dao.UserRepo;

import java.util.List;

@Service
public class LoanServiceImpl implements LoanService {

    @Autowired
    private LoanRepository loanRepository;

	@Override
	public Loan saveloan(Loan loan) {
		// TODO Auto-generated method stub
		return loanRepository.save(loan);
	}


	public List<Loan> getLoansByUserId(long userId) {
        return loanRepository.findByAccountId(userId);
    }
    
}
