package com.Bank.BankingSystem.User;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.sql.Time;

@Entity
public class M_Passbook {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @NotNull
    private LocalDateTime date;

    @NotNull
    private Time time;

    private String particulars;

    private double withdrawals;

    private double deposite;

    private double balance;

    @ManyToOne
    @JoinColumn(name = "deposit_id")
    private Deposit deposit;
    
    @ManyToOne
    @JoinColumn(name="transfer_id")
    private Transfer transfer;

    @Column(name = "user_login_id")
    private int userLoginId;

    // getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }

    public Time getTime() {
        return time;
    }

    public void setTime(Time time) {
        this.time = time;
    }

    public String getParticulars() {
        return particulars;
    }

    public void setParticulars(String particulars) {
        this.particulars = particulars;
    }

    public double getWithdrawals() {
        return withdrawals;
    }

    public void setWithdrawals(double withdrawals) {
        this.withdrawals = withdrawals;
    }

    public double getDeposite() {
        return deposite;
    }

    public void setDeposite(double deposite) {
        this.deposite = deposite;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public Deposit getDeposit() {
        return deposit;
    }

    public void setDeposit(Deposit deposit) {
        this.deposit = deposit;
    }

    public int getUserLoginId() {
        return userLoginId;
    }

    public void setUserLoginId(int userLoginId) {
        this.userLoginId = userLoginId;
    }

	@Override
	public String toString() {
		return "M_Passbook [id=" + id + ", date=" + date + ", time=" + time + ", particulars=" + particulars
				+ ", withdrawals=" + withdrawals + ", deposite=" + deposite + ", balance=" + balance + ", deposit="
				+ deposit + ", userLoginId=" + userLoginId + "]";
	}

	public M_Passbook(int id, @NotNull LocalDateTime date, @NotNull Time time, String particulars, double withdrawals,
			double deposite, double balance, Deposit deposit, int userLoginId) {
		super();
		this.id = id;
		this.date = date;
		this.time = time;
		this.particulars = particulars;
		this.withdrawals = withdrawals;
		this.deposite = deposite;
		this.balance = balance;
		this.deposit = deposit;
		this.userLoginId = userLoginId;
	}

	public M_Passbook() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void setTransfer(@Valid Transfer transfer) {
		// TODO Auto-generated method stub
		
	}
	
	
	
	
}
