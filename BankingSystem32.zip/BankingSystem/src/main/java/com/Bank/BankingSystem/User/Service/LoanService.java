package com.Bank.BankingSystem.User.Service;

import java.util.List;

import com.Bank.BankingSystem.User.Loan;
import com.Bank.BankingSystem.User.User;

public interface LoanService {
    public Loan saveloan(Loan loan);

	public List<Loan> getLoansByUserId(long userId);
}
