package com.Bank.BankingSystem.User.Dao;

import java.util.List;

import com.Bank.BankingSystem.User.Deposit;

public interface DepositService {
    void saveDeposit(Deposit deposit);
    List<Deposit> getAllDeposits();
    Deposit getDepositById(int id);
    void deleteDepositById(int id);
	List<Deposit> getAllDepositsByUserId(int userId);
}
