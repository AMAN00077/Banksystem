package com.Bank.BankingSystem.User;

import java.time.LocalDateTime;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public class Withdrawal {

    @NotNull(message = "Amount is required")
    @Min(value = 1, message = "Amount must be greater than 0")
    private Double amount;
    
    private LocalDateTime time;

    

    public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public LocalDateTime getTime() {
		return time;
	}

	public void setTime(LocalDateTime time) {
		this.time = time;
	}

	public Withdrawal() {}

    public Withdrawal(Double amount, LocalDateTime time) {
        this.amount = amount;
        this.time = time;
    }

    @Override
    public String toString() {
        return "Withdrawal [amount=" + amount + ", time=" + time + "]";
    }
}
