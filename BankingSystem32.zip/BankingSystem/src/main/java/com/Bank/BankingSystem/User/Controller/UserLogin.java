package com.Bank.BankingSystem.User.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.Bank.BankingSystem.User.User;
import com.Bank.BankingSystem.User.UserHome;
import com.Bank.BankingSystem.User.Service.UserService;

import jakarta.validation.Valid;

@Controller
public class UserLogin {
    static int id;

    @Autowired
    private UserService service;

    @GetMapping("/UserLogin")
    public String getLogin(Model model) {
        model.addAttribute("userhome", new UserHome());
        return "userhomehtml";
    }

    @PostMapping("/LoginStatus")
    public String getLoginStatus(@Valid @ModelAttribute("userhome") UserHome userhome, BindingResult bindingResult, Model model) {
        if (bindingResult.hasErrors()) {
            return "userhomehtml";
        }

        List<User> dbUsers = service.userlist();
        boolean found = false;

        for (User ur : dbUsers) {
            if (ur.getUsername().equals(userhome.getUsername()) && ur.getUserpassword().equals(userhome.getUserpassword()) && ur.getUserdob().equals(userhome.getUserdob())) {
                id = ur.getId();
                System.out.println("Id = " + id);
                found = true;
                break;
            }
        }

        if (found) {
            return "UserDashboard";
        } else {
            model.addAttribute("error", "Incorrect username, password, or date of birth");
            return "userhomehtml";
        }
    }
    @GetMapping("/logout")
    public String getLogout(Model model) {
        return "redirect:/UserLogin";
    }
  
}
