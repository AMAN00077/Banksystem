package com.Bank.BankingSystem.User;

import java.sql.Date;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Entity
public class User {
    
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
    private List<Transfer> transfers;

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
    private List<Deposit> deposits;
    
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
    private List<Loan> loans;
//
    @NotBlank(message = "First name is mandatory")
    @Size(max = 50, message = "First name should not exceed 50 characters")
    private String userfirstname;

    @NotBlank(message = "Last name is mandatory")
    @Size(max = 50, message = "Last name should not exceed 50 characters")
    private String userlastname;

    @NotBlank(message = "Address is mandatory")
    @Size(max = 100, message = "Address should not exceed 100 characters")
    private String useraddress;

    @NotNull(message = "Date of birth is mandatory")
    @Past(message = "Date of birth must be in the past")
    private Date userdob;

    @NotBlank(message = "Email is mandatory")
    @Email(message = "Email should be valid")
    private String useremail;

    @NotBlank(message = "Gender is mandatory")
    private String usergender;

    @NotNull(message = "Mobile number is mandatory")
    @Pattern(regexp = "\\d{10}", message = "Mobile number should be 10 digits")
    private String usermob;

    @NotNull(message = "Aadhar number is mandatory")
    @Pattern(regexp = "\\d{12}", message = "Aadhar number should be 12 digits")
    private String useraadharno;

    @NotBlank(message = "PAN number is mandatory")
    @Pattern(regexp = "[A-Z]{5}[0-9]{4}[A-Z]{1}", message = "PAN number should be valid")
    private String userpanno;

    @NotBlank(message = "Account type is mandatory")
    private String useracctype;

    @NotBlank(message = "Username is mandatory")
    @Size(min=3,max = 30, message = "Username should not exceed 30 characters")
    private String username;

    @NotBlank(message = "Password is mandatory")
    @Size(min = 8, message = "Password should be at least 8 characters")
    private String userpassword;

//    @NotBlank(message = "OTP is mandatory")
//    private String otp;

    private long accountno;

    private LocalDateTime accopeningdatentime;

    @Lob
    @Column(name = "profile", length = 100000000)
    private byte[] userimage;

    @Lob
    @Column(name = "aadharpic", length = 100000000)
    private byte[] aadhar;

    @Lob
    @Column(name = "panpic", length = 100000000)
    private byte[] pan;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public List<Transfer> getTransfers() {
		return transfers;
	}

	public void setTransfers(List<Transfer> transfers) {
		this.transfers = transfers;
	}

	public List<Deposit> getDeposits() {
		return deposits;
	}

	public void setDeposits(List<Deposit> deposits) {
		this.deposits = deposits;
	}

	public String getUserfirstname() {
		return userfirstname;
	}

	public void setUserfirstname(String userfirstname) {
		this.userfirstname = userfirstname;
	}

	public String getUserlastname() {
		return userlastname;
	}

	public void setUserlastname(String userlastname) {
		this.userlastname = userlastname;
	}

	public String getUseraddress() {
		return useraddress;
	}

	public void setUseraddress(String useraddress) {
		this.useraddress = useraddress;
	}

	public Date getUserdob() {
		return userdob;
	}

	public void setUserdob(Date userdob) {
		this.userdob = userdob;
	}

	public String getUseremail() {
		return useremail;
	}

	public void setUseremail(String useremail) {
		this.useremail = useremail;
	}

	public String getUsergender() {
		return usergender;
	}

	public void setUsergender(String usergender) {
		this.usergender = usergender;
	}

	public String getUsermob() {
		return usermob;
	}

	public void setUsermob(String usermob) {
		this.usermob = usermob;
	}

	public String getUseraadharno() {
		return useraadharno;
	}

	public void setUseraadharno(String useraadharno) {
		this.useraadharno = useraadharno;
	}

	public String getUserpanno() {
		return userpanno;
	}

	public void setUserpanno(String userpanno) {
		this.userpanno = userpanno;
	}

	public String getUseracctype() {
		return useracctype;
	}

	public void setUseracctype(String useracctype) {
		this.useracctype = useracctype;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUserpassword() {
		return userpassword;
	}

	public void setUserpassword(String userpassword) {
		this.userpassword = userpassword;
	}

	public long getAccountno() {
		return accountno;
	}

	public void setAccountno(long accountno) {
		this.accountno = accountno;
	}

	public LocalDateTime getAccopeningdatentime() {
		return accopeningdatentime;
	}

	public void setAccopeningdatentime(LocalDateTime accopeningdatentime) {
		this.accopeningdatentime = accopeningdatentime;
	}

	public byte[] getUserimage() {
		return userimage;
	}

	public void setUserimage(byte[] userimage) {
		this.userimage = userimage;
	}

	public byte[] getAadhar() {
		return aadhar;
	}

	public void setAadhar(byte[] aadhar) {
		this.aadhar = aadhar;
	}

	public byte[] getPan() {
		return pan;
	}

	public void setPan(byte[] pan) {
		this.pan = pan;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", transfers=" + transfers + ", deposits=" + deposits + ", userfirstname="
				+ userfirstname + ", userlastname=" + userlastname + ", useraddress=" + useraddress + ", userdob="
				+ userdob + ", useremail=" + useremail + ", usergender=" + usergender + ", usermob=" + usermob
				+ ", useraadharno=" + useraadharno + ", userpanno=" + userpanno + ", useracctype=" + useracctype
				+ ", username=" + username + ", userpassword=" + userpassword + ", accountno=" + accountno
				+ ", accopeningdatentime=" + accopeningdatentime + ", userimage=" + Arrays.toString(userimage)
				+ ", aadhar=" + Arrays.toString(aadhar) + ", pan=" + Arrays.toString(pan) + "]";
	}

	public User(int id, List<Transfer> transfers, List<Deposit> deposits,
			@NotBlank(message = "First name is mandatory") @Size(max = 50, message = "First name should not exceed 50 characters") String userfirstname,
			@NotBlank(message = "Last name is mandatory") @Size(max = 50, message = "Last name should not exceed 50 characters") String userlastname,
			@NotBlank(message = "Address is mandatory") @Size(max = 100, message = "Address should not exceed 100 characters") String useraddress,
			@NotNull(message = "Date of birth is mandatory") @Past(message = "Date of birth must be in the past") Date userdob,
			@NotBlank(message = "Email is mandatory") @Email(message = "Email should be valid") String useremail,
			@NotBlank(message = "Gender is mandatory") String usergender,
			@NotNull(message = "Mobile number is mandatory") @Pattern(regexp = "\\d{10}", message = "Mobile number should be 10 digits") String usermob,
			@NotNull(message = "Aadhar number is mandatory") @Pattern(regexp = "\\d{12}", message = "Aadhar number should be 12 digits") String useraadharno,
			@NotBlank(message = "PAN number is mandatory") @Pattern(regexp = "[A-Z]{5}[0-9]{4}[A-Z]{1}", message = "PAN number should be valid") String userpanno,
			@NotBlank(message = "Account type is mandatory") String useracctype,
			@NotBlank(message = "Username is mandatory") @Size(max = 30, message = "Username should not exceed 30 characters") String username,
			@NotBlank(message = "Password is mandatory") @Size(min = 8, message = "Password should be at least 8 characters") String userpassword,
			long accountno, LocalDateTime accopeningdatentime, byte[] userimage, byte[] aadhar, byte[] pan) {
		super();
		this.id = id;
		this.transfers = transfers;
		this.deposits = deposits;
		this.userfirstname = userfirstname;
		this.userlastname = userlastname;
		this.useraddress = useraddress;
		this.userdob = userdob;
		this.useremail = useremail;
		this.usergender = usergender;
		this.usermob = usermob;
		this.useraadharno = useraadharno;
		this.userpanno = userpanno;
		this.useracctype = useracctype;
		this.username = username;
		this.userpassword = userpassword;
		this.accountno = accountno;
		this.accopeningdatentime = accopeningdatentime;
		this.userimage = userimage;
		this.aadhar = aadhar;
		this.pan = pan;
	}

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	
    
    
}
    

   