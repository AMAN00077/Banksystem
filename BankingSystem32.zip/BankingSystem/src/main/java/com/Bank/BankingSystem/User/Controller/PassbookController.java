package com.Bank.BankingSystem.User.Controller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.Bank.BankingSystem.User.M_Passbook;
import com.Bank.BankingSystem.User.Service.PassbookService;

@Controller
public class PassbookController {

    @Autowired
    private PassbookService passbookService;

    @GetMapping("/passbook")
    public String showPassbook(Model model) {
        int userId = UserLogin.id;
        List<M_Passbook> passbookEntries = passbookService.getPassbookEntriesByUserId(userId);

        model.addAttribute("passbookEntries", passbookEntries);

        return "passbook";
    }
}
