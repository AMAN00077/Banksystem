package com.Bank.BankingSystem.User.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Bank.BankingSystem.User.User;
import com.Bank.BankingSystem.User.Dao.UserRepo;

@Service
public class UserDaoImp  implements UserService{
	
	@Autowired
	private UserRepo userrepo;
	
	

	@Override
	public User saveuser(User user) {
		long a=ThreadLocalRandom.current().nextLong(100000000, 999999999);
		user.setAccountno(a);
		user.setAccopeningdatentime(LocalDateTime.now());
		return userrepo.save(user);
	}

	@Override
	public List<User> userlist() {
		// TODO Auto-generated method stub
		List<User>findall=(List<User>) userrepo.findAll();
		return findall;
	}

	@Override
	public User findbyid(int id) {
		// TODO Auto-generated method stub
		Optional<User> byId = userrepo.findById(id);
		User user = byId.orElse(null);
		return user;
	}
//	public User findUserByUsernameAndPassword(String username, String password) {
//        return userrepo.findByUsernameAndUserpassword(username, password);
//    }
//	@Override
//	public User findByAccNo(long id) {
//		// TODO Auto-generated method stub
//		return userrepo.findbyno(id);
//	}

}
