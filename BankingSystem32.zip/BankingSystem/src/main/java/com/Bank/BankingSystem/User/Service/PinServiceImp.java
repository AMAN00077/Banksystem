package com.Bank.BankingSystem.User.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Bank.BankingSystem.User.PIN;
import com.Bank.BankingSystem.User.Dao.PinRepo;

@Service
public class PinServiceImp implements PinService {

    @Autowired
    private PinRepo pinrepo;

    @Override
    public PIN savepin(PIN pin) {
        return pinrepo.save(pin);
    }

    @Override
    public boolean exsistid(int id) {
        return pinrepo.existsById(id);
    }

    public boolean verifyPin(int userId, String pinCode) {
        PIN pin = pinrepo.findById(userId).orElse(null);
        return pin != null && pin.getTpin().equals(pinCode);
    }

	@Override
	public boolean existsById(int userId) {
		// TODO Auto-generated method stub
		 return pinrepo.existsById(userId);
	}
}
