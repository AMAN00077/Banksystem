package com.Bank.BankingSystem.User.Dao;

import com.Bank.BankingSystem.User.M_Passbook;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PassbookRepository extends JpaRepository<M_Passbook, Integer> {
    M_Passbook findTopByUserLoginIdOrderByDateDescTimeDesc(int userLoginId);

	List<M_Passbook> findByUserLoginIdOrderByDateDescTimeDesc(int userId);
}
