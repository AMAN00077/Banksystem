package com.Bank.BankingSystem.User.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Bank.BankingSystem.User.Loan;

@Repository
public interface LoanRepository extends JpaRepository<Loan, Integer> {
	List<Loan> findByAccountId(long accountId);
}
