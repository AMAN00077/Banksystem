package com.Bank.BankingSystem.User;

import java.time.LocalDateTime;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class Payment {

    @NotBlank(message = "Payment recipient is required")
    private String recipient;
    
    @NotNull(message = "Amount is required")
    @Min(value = 1, message = "Amount must be greater than 0")
    private Double amount;
    
    private LocalDateTime time;

    public String getRecipient() {
		return recipient;
	}

	public void setRecipient(String recipient) {
		this.recipient = recipient;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public LocalDateTime getTime() {
		return time;
	}

	public void setTime(LocalDateTime time) {
		this.time = time;
	}

	public Payment() {}

    public Payment(String recipient, Double amount, LocalDateTime time) {
        this.recipient = recipient;
        this.amount = amount;
        this.time = time;
    }

    @Override
    public String toString() {
        return "Payment [recipient=" + recipient + ", amount=" + amount + ", time=" + time + "]";
    }
}
