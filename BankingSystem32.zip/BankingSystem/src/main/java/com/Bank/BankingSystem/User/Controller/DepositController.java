package com.Bank.BankingSystem.User.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.Bank.BankingSystem.User.Deposit;
import com.Bank.BankingSystem.User.User;
import com.Bank.BankingSystem.User.Dao.DepositService;
import com.Bank.BankingSystem.User.Dao.UserRepo;
import com.Bank.BankingSystem.User.M_Passbook;
import com.Bank.BankingSystem.User.Service.PassbookService;

import jakarta.validation.Valid;

import java.time.LocalDateTime;
import java.sql.Time;
import java.util.List;

@Controller
public class DepositController {

    @Autowired
    private DepositService depositService;

    @Autowired
    private UserRepo userRepository;

    @Autowired
    private PassbookService passbookService;

    @GetMapping("/deposit")
    public String showDepositForm(Model model) {
        model.addAttribute("deposit", new Deposit());

        int userId = UserLogin.id;
        List<Deposit> depositHistory = depositService.getAllDepositsByUserId(userId);
        model.addAttribute("depositHistory", depositHistory);

        return "deposit";
    }

    @PostMapping("/deposit")
    public String processDeposit(@ModelAttribute("deposit") @Valid Deposit deposit, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "deposit";
        }

        int userId = UserLogin.id;

        User user = userRepository.findById(userId).orElse(null);

        if (user == null) {
            result.rejectValue("user", "error.user", "User not found");
            return "deposit";
        }

        deposit.setUser(user);
        deposit.setUserLoginId(userId);

        depositService.saveDeposit(deposit);

        double currentBalance = passbookService.getLatestBalance(userId);
        System.out.println(currentBalance);

        double newBalance = currentBalance + deposit.getAmount();

        M_Passbook passbookEntry = new M_Passbook();
        passbookEntry.setDate(LocalDateTime.now());
        passbookEntry.setTime(Time.valueOf(LocalDateTime.now().toLocalTime()));
        passbookEntry.setParticulars("Deposit");
        passbookEntry.setWithdrawals(0);
        passbookEntry.setDeposite(deposit.getAmount());
        passbookEntry.setDeposit(deposit); // Associate deposit with passbook
        passbookEntry.setBalance(newBalance);
        passbookEntry.setUserLoginId(userId);

        passbookService.savePassbookEntry(passbookEntry);

        List<Deposit> depositHistory = depositService.getAllDepositsByUserId(userId);
        model.addAttribute("depositHistory", depositHistory);

        model.addAttribute("successMessage", "Deposit successful!");

        return "depositesuccess";
    }
}
