//package com.Bank.BankingSystem.User.Controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.validation.BindingResult;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.SessionAttributes;
//
//import com.Bank.BankingSystem.User.PIN;
//import com.Bank.BankingSystem.User.Service.PinService;
//import com.Bank.BankingSystem.User.Transfer;
//import com.Bank.BankingSystem.User.Service.TransferService;
//
//import jakarta.transaction.Transactional;
//import jakarta.validation.Valid;
//
//@Controller
//@Transactional
//@SessionAttributes("transfer")
//public class PinController {
//
//    @Autowired
//    private PinService ps;
//
//    @Autowired
//    private TransferService transferService;
//
//    @GetMapping("/setpin")
//    public String setPinForm(Model model) {
//        model.addAttribute("pin", new PIN());
//        return "userpin";
//    }
//
//    @GetMapping("/set")
//    public String setPin(@Valid @ModelAttribute("pin") PIN pin, BindingResult bindingResult, Model model) {
//        if (bindingResult.hasErrors()) {
//            return "userpin";
//        }
//        pin.setId(UserLogin.id);
//        ps.savepin(pin);
//        return "redirect:/fundtransfer"; // Redirect to transfer form after setting PIN
//    }
//
//    @GetMapping("/fundtransfer")
//    public String getPin(Model model) {
//        if (ps.existsById(UserLogin.id)) {
//            return "fundtransfer";
//        } else {
//            PIN pin = new PIN();
//            pin.setId(UserLogin.id);
//            model.addAttribute("pin", pin);
//            return "userpin";
//        }
//    }
//
//    @GetMapping("/verifyPin")
//    public String showPinVerificationForm(Model model) {
//        model.addAttribute("pin", new PIN());
//        return "verifyPin";
//    }
//
//    @PostMapping("/verifyPin")
//    public String verifyPin(@Valid @ModelAttribute("pin") PIN pin, BindingResult bindingResult, Model model, @ModelAttribute("transfer") Transfer transfer) {
//        if (bindingResult.hasErrors()) {
//            return "verifyPin";
//        }
//
//        int userId = UserLogin.id;
//
//        if (ps.existsById(userId) && ps.verifyPin(userId, pin.getTpin())) {
//            // PIN is correct, complete the transfer
//            transferService.savetransfer(transfer);
//
//            // Clear the session attribute and redirect to success page
//            model.addAttribute("successMessage", "Transfer successful!");
//            return "redirect:/transferSuccess";
//        } else {
//            bindingResult.rejectValue("tpin", "error.pin", "Invalid PIN");
//            return "verifyPin";
//        }
//    }
//}
