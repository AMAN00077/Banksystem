package com.Bank.BankingSystem.User.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.Bank.BankingSystem.User.Deposit;

public interface DepositRepo extends JpaRepository<Deposit, Integer> {

	List<Deposit> findByUserId(int userId);
}
