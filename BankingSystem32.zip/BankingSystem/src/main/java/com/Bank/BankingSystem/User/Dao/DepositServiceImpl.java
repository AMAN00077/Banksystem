package com.Bank.BankingSystem.User.Dao;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Bank.BankingSystem.User.Deposit;
import com.Bank.BankingSystem.User.Dao.DepositRepo;

@Service
public class DepositServiceImpl implements DepositService {

    @Autowired
    private DepositRepo depositRepo;

    @Override
    public void saveDeposit(Deposit deposit) {
        deposit.setTime(LocalDateTime.now());
        depositRepo.save(deposit);
    }

    @Override
    public List<Deposit> getAllDeposits() {
        return depositRepo.findAll();
    }

    @Override
    public Deposit getDepositById(int id) {
        return depositRepo.findById(id).orElse(null);
    }

    @Override
    public void deleteDepositById(int id) {
        depositRepo.deleteById(id);
    }

    @Override
    public List<Deposit> getAllDepositsByUserId(int userId) {
        return depositRepo.findByUserId(userId);
    }
}
