package com.Bank.BankingSystem.User.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.Bank.BankingSystem.User.M_Passbook;
import com.Bank.BankingSystem.User.PIN;
import com.Bank.BankingSystem.User.Service.PinService;
import com.Bank.BankingSystem.User.Transfer;
import com.Bank.BankingSystem.User.User;
import com.Bank.BankingSystem.User.Dao.UserRepo;
import com.Bank.BankingSystem.User.Service.PassbookService;
import com.Bank.BankingSystem.User.Service.TransferService;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

import java.time.LocalDateTime;
import java.sql.Time;

@Controller
@Transactional
@SessionAttributes("transfer")
public class BankingController {

    @Autowired
    private PinService pinService;

    @Autowired
    private TransferService transferService;

    @Autowired
    private UserRepo userRepository;

    @Autowired
    private PassbookService passbookService;

    @GetMapping("/setpin")
    public String setPinForm(Model model) {
        model.addAttribute("pin", new PIN());
        return "userpin";
    }

    @PostMapping("/setpin")
    public String setPin(@Valid @ModelAttribute("pin") PIN pin, BindingResult bindingResult, Model model) {
        if (bindingResult.hasErrors()) {
            return "userpin";
        }
        pin.setId(UserLogin.id);
        pinService.savepin(pin);
        return "redirect:/transfer11"; 
    }

    @GetMapping("/transfer11")
    public String showTransferForm(Model model) {
        if (!pinService.existsById(UserLogin.id)) {
            PIN pin = new PIN();
            pin.setId(UserLogin.id);
            model.addAttribute("pin", pin);
            return "userpin";
        }

        model.addAttribute("transfer", new Transfer());
        return "transfer";
    }

    @GetMapping("/transfer")
    public String processTransfer(@ModelAttribute("transfer") @Valid Transfer transfer, BindingResult result,
                                  Model model) {
        if (result.hasErrors()) {
            return "transfer";
        }

        int userId = UserLogin.id;

        User user = userRepository.findById(userId).orElse(null);

        if (user == null) {
            result.rejectValue("user", "error.user", "User not found");
            return "transfer";
        }

        transfer.setUser(user);
        transfer.setUserLoginId(userId);

        double currentBalance = passbookService.getLatestBalance(userId);

        if (currentBalance < transfer.getAmount()) {
            result.rejectValue("amount", "error.amount", "Insufficient balance");
            return "transfer";
        }

        model.addAttribute("transfer", transfer);

        return "redirect:/verifyPin";
    }

    @GetMapping("/verifyPin")
    public String showPinVerificationForm(Model model) {
        model.addAttribute("pin", new PIN());
        return "verifyPin";
    }

    @PostMapping("/verifyPin")
    public String verifyPin(@Valid @ModelAttribute("pin") PIN pin, BindingResult bindingResult, Model model, @ModelAttribute("transfer") Transfer transfer, SessionStatus status) {
        if (bindingResult.hasErrors()) {
            return "verifyPin";
        }

        int userId = UserLogin.id;

        if (pinService.existsById(userId) && pinService.verifyPin(userId, pin.getTpin())) {
            User user = transfer.getUser();
            double currentBalance = passbookService.getLatestBalance(userId);
            double newBalance = currentBalance - transfer.getAmount();

            M_Passbook passbookEntry = new M_Passbook();
            passbookEntry.setDate(LocalDateTime.now());
            passbookEntry.setTime(Time.valueOf(LocalDateTime.now().toLocalTime()));
            passbookEntry.setParticulars("Transfer");
            passbookEntry.setWithdrawals(transfer.getAmount());
            passbookEntry.setDeposite(0);
            passbookEntry.setBalance(newBalance);
            passbookEntry.setUserLoginId(userId);
            passbookEntry.setTransfer(transfer); // Associate the transfer with the passbook

            passbookService.savePassbookEntry(passbookEntry);

            transferService.savetransfer(transfer);

            model.addAttribute("successMessage", "Transfer successful!");
            status.setComplete();
            return "redirect:/transferSuccess";
        } else {
            bindingResult.rejectValue("tpin", "error.pin", "Invalid PIN");
            return "verifyPin";
        }
    }

    @GetMapping("/transferSuccess")
    public String transferSuccess(SessionStatus status) {
        status.setComplete();
        return "transferSuccess";
    }
}
