package com.Bank.BankingSystem.User.Controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.Bank.BankingSystem.User.Loan;
import com.Bank.BankingSystem.User.Service.LoanService;
import com.Bank.BankingSystem.User.Dao.UserRepo;

@Controller
public class LoanController {

    @Autowired
    private LoanService loanService;

    @Autowired
    private UserRepo userRepository;

    @GetMapping("/loan")
    public String showLoanForm(Model model) {
        model.addAttribute("loan", new Loan());
        return "loanForm";
    }

    @PostMapping("/apply")
    public String applyForLoan(@ModelAttribute Loan loan, Model model) {
        long userId = UserLogin.id; 
        System.out.println(userId);

        loan.setAccountId(userId);

        LocalDate issueDate = LocalDate.now();
        loan.setIssueDate(issueDate);

        double interestRate;
        switch (loan.getLoanType()) {
            case "Personal Loan":
                interestRate = 0.10; // 10%
                break;
            case "Home Loan":
                interestRate = 0.05; // 5%
                break;
            case "Car Loan":
                interestRate = 0.08; // 8%
                break;
            default:
                interestRate = 0.10; // default to 10%
                break;
        }
        loan.setInterestRate(interestRate);

        LocalDate dueDate = issueDate.plusYears(loan.getLoanTerm());
        loan.setDueDate(dueDate);

        double principal = loan.getLoanAmount();
        double totalInterest = principal * interestRate * loan.getLoanTerm();
        double returnAmount = principal + totalInterest;
        loan.setReturnLoanAmt(returnAmount);

        loanService.saveloan(loan);

        model.addAttribute("loan", loan);

        return "loanConfirmation";
    }

    
    @GetMapping("/loanHistory")
    public String getLoanHistory(Model model) {
        long userId = UserLogin.id; 
        List<Loan> loanHistory = loanService.getLoansByUserId(userId);
        model.addAttribute("loanHistory", loanHistory);
        return "loanHistory";
    }
}
