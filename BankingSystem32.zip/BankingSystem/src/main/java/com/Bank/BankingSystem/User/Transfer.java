package com.Bank.BankingSystem.User;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Entity
public class Transfer {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
    @ManyToOne
    private User user;
    
    @NotBlank(message = "Recipient account number is required")
    private String recipientAccountNumber;
    
    @NotBlank(message = "Recipient recipientName is required")
    private String recipientName;
    
    @NotBlank(message = "Recipient recipient_IFSC is required")
    private String recipient_IFSC; 

    @NotNull(message = "Amount is required")
    @Min(value = 1, message = "Amount must be greater than 0")
    private Double amount;
    
    private LocalDateTime time;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getRecipientAccountNumber() {
		return recipientAccountNumber;
	}

	public void setRecipientAccountNumber(String recipientAccountNumber) {
		this.recipientAccountNumber = recipientAccountNumber;
	}

	public String getRecipientName() {
		return recipientName;
	}

	public void setRecipientName(String recipientName) {
		this.recipientName = recipientName;
	}

	public String getRecipient_IFSC() {
		return recipient_IFSC;
	}

	public void setRecipient_IFSC(String recipient_IFSC) {
		this.recipient_IFSC = recipient_IFSC;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public LocalDateTime getTime() {
		return time;
	}

	public void setTime(LocalDateTime time) {
		this.time = time;
	}

	@Override
	public String toString() {
		return "Transfer [id=" + id + ", user=" + user + ", recipientAccountNumber=" + recipientAccountNumber
				+ ", recipientName=" + recipientName + ", recipient_IFSC=" + recipient_IFSC + ", amount=" + amount
				+ ", time=" + time + "]";
	}

	public Transfer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Transfer(int id, User user,
			@NotBlank(message = "Recipient account number is required") String recipientAccountNumber,
			@NotBlank(message = "Recipient recipientName is required") String recipientName,
			@NotBlank(message = "Recipient recipient_IFSC is required") String recipient_IFSC,
			@NotNull(message = "Amount is required") @Min(value = 1, message = "Amount must be greater than 0") Double amount,
			LocalDateTime time) {
		super();
		this.id = id;
		this.user = user;
		this.recipientAccountNumber = recipientAccountNumber;
		this.recipientName = recipientName;
		this.recipient_IFSC = recipient_IFSC;
		this.amount = amount;
		this.time = time;
	}

	public void setUser(int id2) {
		// TODO Auto-generated method stub
		
	}

	public void setUserLoginId(int userId) {
		// TODO Auto-generated method stub
		
	}


}
