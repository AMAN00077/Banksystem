package com.Bank.BankingSystem.User.Service;


import java.time.LocalDate;
import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.Bank.BankingSystem.User.Transfer;
import com.Bank.BankingSystem.User.Dao.TransferRepository;

@Service
public class TransferServiceImpl implements TransferService {

	@Autowired
	private TransferRepository tr;
	@Override
	public Transfer savetransfer(Transfer transfer) {
		
		transfer.setTime(LocalDateTime.now());
		// TODO Auto-generated method stub
		return tr.save(transfer);
	}

    
}
