package com.Bank.BankingSystem.User;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

@Entity
public class Deposit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @ManyToOne
    private User user;

    @NotNull(message = "Amount is required")
    @Min(value = 1, message = "Amount must be greater than 0")
    private Double amount;

    private LocalDateTime time;


    
    

    @Override
    public String toString() {
        return "Deposit [id=" + id + ", user=" + user + ", amount=" + amount + ", time=" + time + "]";
    }

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public LocalDateTime getTime() {
		return time;
	}

	public void setTime(LocalDateTime time) {
		this.time = time;
	}

	public Deposit() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Deposit(int id, User user,
			@NotNull(message = "Amount is required") @Min(value = 1, message = "Amount must be greater than 0") Double amount,
			LocalDateTime time) {
		super();
		this.id = id;
		this.user = user;
		this.amount = amount;
		this.time = time;
	}

	public void setUserLoginId(int userId) {
		// TODO Auto-generated method stub
		
	}

   
}
