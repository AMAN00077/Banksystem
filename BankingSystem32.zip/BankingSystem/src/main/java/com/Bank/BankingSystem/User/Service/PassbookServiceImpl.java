package com.Bank.BankingSystem.User.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Bank.BankingSystem.User.M_Passbook;
import com.Bank.BankingSystem.User.Dao.PassbookRepository;

@Service
public class PassbookServiceImpl implements PassbookService {

    @Autowired
    private PassbookRepository passbookRepository;

    @Override
    public M_Passbook savePassbookEntry(M_Passbook passbookEntry) {
        return passbookRepository.save(passbookEntry);
    }

    @Override
    public double getLatestBalance(int userId) {
        M_Passbook latestEntry = passbookRepository.findTopByUserLoginIdOrderByDateDescTimeDesc(userId);
        return (latestEntry != null) ? latestEntry.getBalance() : 0.0;
    }

    @Override
    public List<M_Passbook> getPassbookEntriesByUserId(int userId) {
        return passbookRepository.findByUserLoginIdOrderByDateDescTimeDesc(userId);
    }
}
