package com.Bank.BankingSystem.User.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.Bank.BankingSystem.User.User;
import com.Bank.BankingSystem.User.Dao.UserRepo;

public interface UserService {
	@Autowired
//	private UserRepo a;
	public User saveuser(User user);
	public List<User>userlist();
	public User findbyid(int id);
	
	
//	public User findByAccNo(long id);

}
