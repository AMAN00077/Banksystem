package com.Bank.BankingSystem.User;

import java.sql.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Size;

@Entity
public class UserHome {
	
	@Id
	private int userid;
	
	@NotBlank(message = "Username cannot be blank")
	@Size(min = 3, max = 50, message = "Username must be between 3 and 50 characters")
	private String username;
	
	@NotBlank(message = "Password cannot be blank")
	@Size(min = 8, message = "Password must be at least 8 characters long")
	private String userpassword;
	
	@NotNull(message = "Date of birth cannot be null")
	@Past(message = "Date of birth must be in the past")
	private Date userdob;

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUserpassword() {
		return userpassword;
	}

	public void setUserpassword(String userpassword) {
		this.userpassword = userpassword;
	}

	public Date getUserdob() {
		return userdob;
	}

	public void setUserdob(Date userdob) {
		this.userdob = userdob;
	}

	@Override
	public String toString() {
		return "UserHome [userid=" + userid + ", username=" + username + ", userpassword=" + userpassword + ", userdob="
				+ userdob + "]";
	}

	public UserHome(int userid, String username, String userpassword, Date userdob) {
		super();
		this.userid = userid;
		this.username = username;
		this.userpassword = userpassword;
		this.userdob = userdob;
	}

	public UserHome() {
		super();
		// Default constructor
	}
}
