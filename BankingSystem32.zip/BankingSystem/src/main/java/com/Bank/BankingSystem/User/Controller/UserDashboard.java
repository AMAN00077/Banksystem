package com.Bank.BankingSystem.User.Controller;

import java.sql.Date;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.GetMapping;

import com.Bank.BankingSystem.User.User;
import com.Bank.BankingSystem.User.Service.UserService;
import com.Bank.BankingSystem.User.Service.PassbookService;

@Controller
public class UserDashboard {

	static String n = "   ";
	static String name;
	static long acc;
	static String acctype;
	static String pan;
	static LocalDateTime date;
	static String email;
	static Date Dob;
	static double currentBalance;

	@Autowired
	private UserService service;

	@Autowired
	private PassbookService passbookService;

	@GetMapping("/userList")
	public String userList(Model model) {
		List<User> users = service.userlist();
		model.addAttribute("users", users);
		return "userList";
	}

	@GetMapping("/account")
	public String getaccinfo(Model model) {
		System.out.println(UserLogin.id);
		List<User> dbuser = service.userlist();
		boolean found = false;
		for (User ur : dbuser) {
			if (ur.getId() == UserLogin.id) {
				name = ur.getUserfirstname() + n + ur.getUserlastname();
				acc = ur.getAccountno();
				acctype = ur.getUseracctype();
				pan = ur.getUserpanno();
				date = ur.getAccopeningdatentime();
				email = ur.getUseremail();
				Dob = ur.getUserdob();
				found = true;

				// Fetch current balance for the logged-in user
				currentBalance = passbookService.getLatestBalance(UserLogin.id);
			}
		}
		if (found) {
			model.addAttribute("name", name);
			model.addAttribute("acc", acc);
			model.addAttribute("acctype", acctype);
			model.addAttribute("pan", pan);
			model.addAttribute("date", date);
			model.addAttribute("email", email);
			model.addAttribute("Dob", Dob);
			model.addAttribute("currentBalance", currentBalance); // Add current balance to model
			return "accountInfo";
		} else {
			model.addAttribute("error", "Incorrect username or password ");
			System.out.println(UserLogin.id);
			return "accountInfo";
		}
	}
}
