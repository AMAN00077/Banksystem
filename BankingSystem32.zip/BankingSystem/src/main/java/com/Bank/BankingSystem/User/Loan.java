package com.Bank.BankingSystem.User;

import java.time.LocalDate;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class Loan {
		
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int loanId;
	private long accountId;
	private double loanAmount;
	private double interestRate;
	private int loanTerm; 
	private String loanType;
	private LocalDate issueDate;
	private LocalDate dueDate;
	private double returnLoanAmt;

	@ManyToOne
	private User user;


	public int getLoanId() {
		return loanId;
	}

	public void setLoanId(int loanId) {
		this.loanId = loanId;
	}

	public long getAccountId() {
		return accountId;
	}

	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}

	public double getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}

	public double getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}

	public int getLoanTerm() {
		return loanTerm;
	}

	public void setLoanTerm(int loanTerm) {
		this.loanTerm = loanTerm;
	}

	public String getLoanType() {
		return loanType;
	}

	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}

	public LocalDate getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(LocalDate issueDate) {
		this.issueDate = issueDate;
	}

	public LocalDate getDueDate() {
		return dueDate;
	}

	public void setDueDate(LocalDate dueDate) {
		this.dueDate = dueDate;
	}

	public double getReturnLoanAmt() {
		return returnLoanAmt;
	}

	public void setReturnLoanAmt(double returnLoanAmt) {
		this.returnLoanAmt = returnLoanAmt;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	// Constructors

	public Loan(int loanId, long accountId, double loanAmount, double interestRate, int loanTerm, String loanType,
			LocalDate issueDate, LocalDate dueDate, double returnLoanAmt, User user) {
		super();
		this.loanId = loanId;
		this.accountId = accountId;
		this.loanAmount = loanAmount;
		this.interestRate = interestRate;
		this.loanTerm = loanTerm;
		this.loanType = loanType;
		this.issueDate = issueDate;
		this.dueDate = dueDate;
		this.returnLoanAmt = returnLoanAmt;
		this.user = user;
	}

	public Loan() {
		super();
		// Default constructor
	}

	@Override
	public String toString() {
		return "Loan [loanId=" + loanId + ", accountId=" + accountId + ", loanAmount=" + loanAmount
				+ ", interestRate=" + interestRate + ", loanTerm=" + loanTerm + ", loanType=" + loanType
				+ ", issueDate=" + issueDate + ", dueDate=" + dueDate + ", returnLoanAmt=" + returnLoanAmt
				+ ", user=" + user + "]";
	}
}
