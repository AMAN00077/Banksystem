package com.Bank.BankingSystem.User.Service;

import org.springframework.beans.factory.annotation.Autowired;

import com.Bank.BankingSystem.User.PIN;

public interface PinService {
	@Autowired
	public PIN savepin(PIN pin);
	public boolean exsistid(int id);
	public boolean verifyPin(int userId, String tpin);
	public boolean existsById(int userId);


}
