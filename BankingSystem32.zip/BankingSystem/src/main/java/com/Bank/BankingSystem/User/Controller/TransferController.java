//package com.Bank.BankingSystem.User.Controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.validation.BindingResult;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.SessionAttributes;
//import org.springframework.web.bind.support.SessionStatus;
//
//import com.Bank.BankingSystem.User.Service.TransferService;
//import com.Bank.BankingSystem.User.Transfer;
//import com.Bank.BankingSystem.User.User;
//import com.Bank.BankingSystem.User.Dao.UserRepo;
//import com.Bank.BankingSystem.User.Service.PassbookService;
//
//import jakarta.validation.Valid;
//
//@Controller
//@SessionAttributes("transfer")
//public class TransferController {
//
//    @Autowired
//    private TransferService transferService;
//
//    @Autowired
//    private UserRepo userRepository;
//
//    @Autowired
//    private PassbookService passbookService;
//
//    @GetMapping("/transfer")
//    public String showTransferForm(Model model) {
//        model.addAttribute("transfer", new Transfer());
//        return "transfer";
//    }
//
//    @PostMapping("/transfer")
//    public String processTransfer(@ModelAttribute("transfer") @Valid Transfer transfer, BindingResult result,
//                                  Model model) {
//        if (result.hasErrors()) {
//            return "transfer";
//        }
//
//        // Get the currently logged-in user ID
//        int userId = UserLogin.id;
//
//        // Fetch the user from the database
//        User user = userRepository.findById(userId).orElse(null);
//
//        // Check if the user is found
//        if (user == null) {
//            result.rejectValue("user", "error.user", "User not found");
//            return "transfer";
//        }
//
//        // Set the user for the transfer
//        transfer.setUser(user);
//        transfer.setUserLoginId(userId);
//
//        // Fetch the current balance from the passbook
//        double currentBalance = passbookService.getLatestBalance(userId);
//
//        // Check if sufficient balance is available
//        if (currentBalance < transfer.getAmount()) {
//            result.rejectValue("amount", "error.amount", "Insufficient balance");
//            return "transfer";
//        }
//
//        // Temporarily store the transfer object in the session without saving it
//        model.addAttribute("transfer", transfer);
//
//        // Redirect to PIN verification page
//        return "redirect:/verifyPin";
//    }
//
//    @GetMapping("/transferSuccess")
//    public String transferSuccess(SessionStatus status) {
//        // Clear the session attributes
//        status.setComplete();
//        return "transferSuccess";
//    }
//}
