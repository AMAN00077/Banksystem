package com.Bank.BankingSystem.User.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.Bank.BankingSystem.User.User;
import com.Bank.BankingSystem.User.Service.UserService;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

@Controller
@Transactional
public class UserController {
	@Autowired
	private UserService   userservice;
	@GetMapping("/RegisterUser")
	public String registeruser(Model model) {
		model.addAttribute("user", new User());
		return "userhtml";
	}
	
	@PostMapping("/Loginststatus")
	public String getStatus(@Valid @ModelAttribute("user") User user,BindingResult bindResult,@RequestParam("userimage")MultipartFile imgFile,@RequestParam("aadhar")MultipartFile imgFile1,@RequestParam("pan")MultipartFile imgFile2) {
//		if(bindResult.hasErrors()) {
//			return "userhtml";
//		}
		try {
		user.setUserimage(imgFile.getBytes());
		user.setAadhar(imgFile1.getBytes());
		user.setPan(imgFile2.getBytes());
		}
		catch(Exception e) {
			
		}
		
		userservice.saveuser(user);
		return "redirect:/UserLogin";
		
	}

}
