package com.Bank.BankingSystem.User.Service;

import org.springframework.beans.factory.annotation.Autowired;

import com.Bank.BankingSystem.User.Transfer;

public interface TransferService {
	@Autowired
	public Transfer savetransfer(Transfer transfer);

}
