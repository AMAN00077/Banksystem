// navbarAnimation.js

document.addEventListener('DOMContentLoaded', () => {
    gsap.from("nav ul li", {
        duration: 1,
        y: -30,
        opacity: 0,
        stagger: 0.2,
        ease: "bounce.out"
    });
});
